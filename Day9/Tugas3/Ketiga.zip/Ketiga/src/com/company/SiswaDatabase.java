package com.company;

import java.util.regex.*;
import java.sql.*;
import java.io.*;
import java.util.*;

public class SiswaDatabase {
    public static Connection con;
    public static Statement stmt;
    public static boolean LoggedIn = false;
    public static Scanner keyboard = new Scanner(System.in);

    public static void main(String args[]){
        System.out.println("Cek Login Database");
        System.out.print("Username : ");
        String username = keyboard.nextLine();
        System.out.print("Password : ");
        String password = keyboard.nextLine();
        try {
            Cek(username, password);
            if (LoggedIn) {
                System.out.println("Berhasil Login");
                Conn(username,password);
                menu();
            } else {
                System.out.println("Gagal Login");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void menu() throws Exception {
        int Menus;
        do {
            System.out.println("MENU\n1. Input Data to DB\n2. Edit Data from DB\n3. Delete Data from DB\n0. Exit\n");
            System.out.print("Pilih Menu : ");
            Menus = Integer.parseInt(keyboard.nextLine());
            switch (Menus) {
                case 1:
                    System.out.print("Nickname : ");
                    String name = keyboard.nextLine();
                    System.out.print("Fullname : ");
                    String fullname = keyboard.nextLine();
                    System.out.print("Address : ");
                    String address = keyboard.nextLine();
                    System.out.print("Status : ");
                    String status = keyboard.nextLine();
                    System.out.print("Physics  : ");
                    int physics = Integer.parseInt(keyboard.nextLine());
                    System.out.print("Calculus  : ");
                    int calculus = Integer.parseInt(keyboard.nextLine());
                    System.out.print("Biology  : ");
                    int biology = Integer.parseInt(keyboard.nextLine());
                    InsertDB(name,fullname,address,status,physics,calculus,biology);
                    break;
                case 2:
                    ShowDB();
                    System.out.print("Masukkan ID : ");
                    int id = Integer.parseInt(keyboard.nextLine());
                    System.out.print("Fullname : ");
                    String fullname1 = keyboard.nextLine();
                    System.out.print("Nickname : ");
                    String name1 = keyboard.nextLine();
                    System.out.print("Address : ");
                    String address1 = keyboard.nextLine();
                    System.out.print("Status : ");
                    String status1 = keyboard.nextLine();
                    System.out.print("Physics : ");
                    int physics1 = Integer.parseInt(keyboard.nextLine());
                    System.out.print("Calculus : ");
                    int calculus1 = Integer.parseInt(keyboard.nextLine());
                    System.out.print("Biology : ");
                    int biology1 = Integer.parseInt(keyboard.nextLine());
                    UpdateDB(id,name1,fullname1,address1,status1,physics1, calculus1, biology1);
                    menu();
                    break;
                case 3:
                    ShowDB();
                    System.out.print("Delete ID Data : ");
                    int idDelete = Integer.parseInt(keyboard.nextLine());
                    DeleteDB(idDelete);
                    break;
                default:
                    break;
            }
        } while (Menus != 0);
    }


    public static void Conn(String user, String pass){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection( "jdbc:mysql://127.0.0.1:3306/datasiswa?useJDBCCompliantTimezoneShift=true&serverTimezone=UTC",user,pass);
        }catch(Exception e){
            System.out.println(e);
        }
    }

    public static void ShowDB(){
        try {
            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM data");
            while (rs.next())
                System.out.println(rs.getInt(1) + " " +
                        rs.getString(2) + " " +
                        rs.getString(3) + " " +
                        rs.getString(4) + " " +
                        rs.getString(5) + " " +
                        rs.getString(6) + " " +
                        rs.getString(7) + " " +
                        rs.getString(8));
        }catch (Exception e){
            System.out.println(e);
        }
    }

    public static void DeleteDB(Integer id){
        try {
            stmt = con.createStatement();
            stmt.executeUpdate("DELETE FROM data WHERE id="+id+"");

        }catch (Exception e){
            System.out.println(e);
        }
    }

    public static void UpdateDB(Integer id, String nama, String namalkp, String alamat, String status, Integer fsk, Integer kal, Integer bio) {
        try {
            stmt = con.createStatement();
            stmt.executeUpdate("UPDATE `data` SET `nama` = '"+nama+"', `nm_lengkap` = '"+namalkp+"', `alamat` = '"+alamat+"', `status` = '"+status+"', `fisika` = "+fsk+", `kalkulus` = "+kal+", `biologi` = "+bio+" WHERE `id` = "+id+"");
        }catch (Exception e){
            System.out.println(e);
        }
    }
    public static void InsertDB(String nama, String namalkp, String alamat, String status, Integer fsk, Integer kal, Integer bio){
        try{
            stmt=con.createStatement();
            stmt.executeUpdate("INSERT INTO `data` (`id`, `nama`, `nm_lengkap`, `alamat`, `status`, `fisika`, `kalkulus`, `biologi`) VALUES (NULL, '"+nama+"', '"+namalkp+"', '"+alamat+"', '"+status+"', "+fsk+", "+kal+", "+bio+");");
            con.close();
        }catch (Exception e){
            System.out.println(e);
        }
    }

    public static void Cek(String usern, String pass) throws Exception {
        String user="root";
        String passw="root";
        boolean emailCorrect = Pattern.compile("root", Pattern.CASE_INSENSITIVE).matcher(usern).matches();
        boolean passCorrect = Pattern.compile("root").matcher(pass).matches();
        if (emailCorrect && passCorrect){
            if (Pattern.matches(usern, user) && Pattern.matches(pass, passw)){
                LoggedIn = true;
            } else {
                System.out.println("Username atau Password salah");
            }
        }else {
            System.out.println("Password Harus Sesuai");
        }
    }
}
