package com.company;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class JSON4 {
    public static void main(String args[]){
        JSONObject obj=new JSONObject();
        JSONObject obj1=new JSONObject();
        JSONObject obj2=new JSONObject();

        obj.put("name","sonoo");
        obj.put("age",new Integer(27));
        obj.put("salary",new Double(600000));

        obj1.put("name","sonii");
        obj1.put("age",new Integer(27));
        obj1.put("salary",new Double(600000));

        obj2.put("name","soniaa");
        obj2.put("age",new Integer(27));
        obj2.put("salary",new Double(600000));

        JSONArray arr = new JSONArray();
        arr.add(obj);
        arr.add(obj1);
        arr.add(obj2);

        JSONObject employe=new JSONObject();
        employe.put("employee",arr);

        JSONArray jsonArray = (JSONArray) employe.get("employee");

        for (int i = 0; i < jsonArray.size(); i++)
        {
            JSONObject objectInArray = (JSONObject) jsonArray.get(i);
            String name = (String) objectInArray.get("name");
            double salary = (Double) objectInArray.get("salary");
            int age = (Integer) objectInArray.get("age");
            System.out.println("Nama :" + name+"\n"+ "Gaji :" + salary+"\n"+"Umur :" +age+"\n");
        }
    }
}
