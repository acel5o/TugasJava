package com.company;

import java.util.ArrayList;

public class Manajer extends Worker{


    int TTransport=0;
    int TEntertaint=0;
    int Total=0;
    ArrayList<String> manajer=new ArrayList<>();

    public Manajer(int id, String nama, String jabatan, int pulsa, int gapok) {
        super(id, nama, jabatan, pulsa, gapok);
        // TODO Auto-generated constructor stub
    }

    void Nomor(String tp1, String tp2){
        manajer.add(tp1);
        manajer.add(tp2);
    }

    ArrayList<String> getManajer(){
        return manajer;
    }
    void setAbsen(int absen){
        this.Absen = absen;
    }

    void setEnt(int Ent){
        this.TEntertaint = Ent * 500000;
    }

    int getEnt(){
        return TEntertaint;
    }

    void setTrans(int absen){
        this.TTransport = absen * 50000;
    }

    int getTrans(){
        return TTransport;
    }

    public void GajiTotal(int id){
        if (id == this.IDKaryawan){
            this.Total = this.Gapok + this.TEntertaint + this.TTransport;
        }
    }

    int getTotal(){
        return this.Total;
    }
}
