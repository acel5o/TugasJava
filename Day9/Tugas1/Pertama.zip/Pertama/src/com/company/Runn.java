package com.company;
import java.io.*;
import java.util.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

public class Runn{
    public static ArrayList<Staff> staff = new ArrayList<>();
    public static ArrayList<Manajer> manajer = new ArrayList<>();
    public static void main(String[] args) {
        TampilMenu();
        InputStreamReader r=new InputStreamReader(System.in);
        BufferedReader br=new BufferedReader(r);
        String Menu="";
        try {
            while (!Menu.equals("4")){
                System.out.print("Pilih Menu 1/2/3/4: ");
                Menu=br.readLine();
                switch (Menu){
                    case "1":
                        System.out.println();
                        InputData();
                        break;
                    case "2":
                        String jabatan;
                        System.out.print("Masukan Jabatan: ");
                        jabatan=br.readLine();

                        switch(jabatan){
                            case "Staff":
                                toJsonS();
                                break;
                            case "Manajer":
                                toJsonM();
                                break;
                            default:
                                break;
                        }
                        break;
                    case "3":
                        String file;
                        System.out.print("Masukan File: ");
                        file=br.readLine();

                        switch(file){
                            case "Staff.txt":
                                readJSONS(file);
                                break;
                            case "Manajer":
                                readJSONM(file);
                                break;
                            default:
                                break;
                        }
                        break;
                    default :
                        System.out.println();
                        TampilMenu();
                    break;
                }
            }
        } catch (Exception e){
            System.out.println("Error: "+e);
        }
    }

    private static void InputData(){
        String jabatan;
        String id="";
        String nama="";
        String em2="";
        String em1="";
        String tp2="";
        String tp1="";
        int absen=20;
        int Pulsa = 50000;
        int GapokS = 5000000;
        int GapokM = 10000000;

        try {
            InputStreamReader r=new InputStreamReader(System.in);
            BufferedReader br=new BufferedReader(r);
            System.out.print("Masukan Id: ");
            id=br.readLine();
            System.out.print("Masukan Jabatan: ");
            jabatan=br.readLine();
            System.out.print("Masukan Nama: ");
            nama=br.readLine();
            switch(jabatan){
                case "Staff":
                    System.out.print("Email Kantor: ");
                    em1=br.readLine();
                    System.out.print("Email Pribadi: ");
                    em2=br.readLine();
                    Staff stf = new Staff(Integer.parseInt(id),nama,jabatan,Pulsa,GapokS);
                    stf.setAbsen(absen);
                    stf.setMakan(absen);
                    stf.Email(em1,em2);
                    staff.add(stf);
                break;
                case "Manajer":
                    System.out.print("Telp Kantor: ");
                    tp1=br.readLine();
                    System.out.print("Telp Pribadi: ");
                    tp2=br.readLine();
                    Manajer mng = new Manajer(Integer.parseInt(id),nama,jabatan,Pulsa,GapokM);
                    mng.setAbsen(absen);
                    mng.setTrans(absen);
                    mng.setEnt(absen);
                    mng.Nomor(tp1,tp2);
                    manajer.add(mng);
                break;
                default:
                break;
            }
            System.out.println("Input Data Berhasil!!");
            TampilMenu();
        } catch (Exception e){
            System.out.println(e);
            TampilMenu();
        }
    }

    private static void toJsonM() throws  Exception{
        JSONArray arr = new JSONArray();
        JSONObject employees = new JSONObject();
        for (Manajer obj: manajer){
            JSONObject obj1=new JSONObject();
            obj1.put("Tunjangan Entertaint",obj.getEnt());
            obj1.put("Tunjangan Transport",obj.getTrans());
            obj1.put("Tunjangan Pulsa",obj.getPulsa());
            obj1.put("Telepon",obj.getManajer().get(0));
            obj1.put("Nama",obj.getNama());
            obj1.put("Id",obj.getId());

            arr.add(obj1);
            employees.put("manajer",arr);

        }
        try {
            FileWriter writer = new FileWriter("C:\\SFWBTPNS\\Bootcamp G2 Academy\\Belajar Java\\Har8\\Pertama\\src\\com\\company\\Manajer.txt");
            BufferedWriter buffer = new BufferedWriter(writer);
            String jsonText = JSONValue.toJSONString(employees);
            System.out.println(jsonText);
            buffer.write(jsonText);
            buffer.close();
            writer.close();
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    private static void toJsonS() throws  Exception{
        JSONArray arr = new JSONArray();
        JSONObject employees = new JSONObject();
        for (Staff obj: staff){
            JSONObject obj1=new JSONObject();
            obj1.put("tunjangan makan",obj.getMakan());
            obj1.put("tunjangan pulsa",obj.getPulsa());
            obj1.put("email",obj.getStaff().get(0));
            obj1.put("nama",obj.getNama());
            obj1.put("id",obj.getId());

            arr.add(obj1);
            employees.put("staff",arr);
        }
        try {
            FileWriter writer = new FileWriter("C:\\SFWBTPNS\\Bootcamp G2 Academy\\Belajar Java\\Har8\\Pertama\\src\\com\\company\\Staff.txt");
            BufferedWriter buffer = new BufferedWriter(writer);
            String jsonText = JSONValue.toJSONString(employees);
            System.out.println(jsonText);
            buffer.write(jsonText);
            buffer.close();
            writer.close();
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public static void readJSONM(String filename){
        String textfile = "";
        try{
            FileReader fr = new FileReader(filename);
            BufferedReader br = new BufferedReader(fr);
            int i;
            while ((i = br.read()) != -1) {

                textfile += (char) i;
            }
            fr.close();
            br.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        Object obj=JSONValue.parse(textfile);
        JSONObject jsonObject = (JSONObject) obj;
        JSONArray elm = (JSONArray) jsonObject.get("manajer");
        for (int i = 0, size = elm.size(); i < size; i++)
        {
            JSONObject objectInArray = (JSONObject)elm.get(i);
            System.out.println("id : "+objectInArray.get("id"));
            System.out.println("nama : "+objectInArray.get("nama"));
            System.out.println("telepon : "+objectInArray.get("telepon"));
            System.out.println("tunjangan pulsa : "+objectInArray.get("tunjangan pulsa"));
            System.out.println("tunjangan transport : "+objectInArray.get("tunjangan transport"));
            System.out.println("tunjangan entertaint : "+objectInArray.get("tunjangan entertaint")+"\n");
        }
    }


    public static void readJSONS(String filename){
        String textfile = "";
        try{
            FileReader fr = new FileReader(filename);
            BufferedReader br = new BufferedReader(fr);
            int i;
            while ((i = br.read()) != -1) {

                textfile += (char) i;
            }
            fr.close();
            br.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        Object obj=JSONValue.parse(textfile);
        JSONObject jsonObject = (JSONObject) obj;
        JSONArray elm = (JSONArray) jsonObject.get("staff");
        for (int i = 0, size = elm.size(); i < size; i++)
        {
            JSONObject objectInArray = (JSONObject)elm.get(i);
            System.out.println("id : "+objectInArray.get("id"));
            System.out.println("nama : "+objectInArray.get("nama"));
            System.out.println("email : "+objectInArray.get("email"));
            System.out.println("tunjangan pulsa : "+objectInArray.get("tunjangan pulsa"));
            System.out.println("tunjangan makan : "+objectInArray.get("tunjangan makan"));
        }
    }

    private static void TampilMenu(){
        System.out.println("Silahkan Pilih Menu");
        System.out.println("1. Buat Worker");
        System.out.println("2. Create JSON Format and Write to File");
        System.out.println("3. Read JSON Format from a File, input Filename");
        System.out.println("4. Exit");
    }

}
