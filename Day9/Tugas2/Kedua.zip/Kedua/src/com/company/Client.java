package com.company;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import java.io.*;
import java.net.*;
import java.util.Properties;
import java.io.DataOutputStream;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;


public class Client {
    //Instance Variable br -> scanner
    static InputStreamReader r=new InputStreamReader(System.in);
    static BufferedReader br=new BufferedReader(r);
    static Socket s; // Tampung socket
    static String data;// Variable untuk menampung string data file.txt dari server
    static String filetxt = "";

    //Main Method
    public static void main(String[] args) {
        Menu();
    }

    public static void Menu(){
        try {
            int Menu = 0;
            while(Menu!=99){
                // Print Menu
                System.out.println("Menu");
                System.out.println("1. Connect Socket");
                System.out.println("2. Create FileProses.txt");
                System.out.println("3. Tampil Dilayar, Tulis Ke File, Kirim FTP (Multi Threading)");
                System.out.println("4. Download average.txt dari FTP Server");
                System.out.println("5. Close All Connection");
                System.out.println("99. Exit");
                System.out.println("");
                System.out.print("Input Menu : ");
                Menu = Integer.parseInt(br.readLine());
                switch (Menu){
                    case 1:
                        ConnSocket();
                        break;
                    case 2:
                        NewFile();
                        break;
                    case 3:
                        MultiThreading();
                        break;
                    case 4:
                        Download();
                        break;
                    case 5:
                        ReleaseConn();
                        break;
                    default:
                        break;
                }
            }
        }catch (Exception e){
            System.out.println(e);
        }
    }
    //Method koneksi ke Server
    public static void ConnSocket(){
        try {
            Properties prop = new Properties();
            InputStream input = null;
            input = new FileInputStream("C:\\SFWBTPNS\\Bootcamp G2 Academy\\Belajar Java\\Har8\\Kedua\\src\\com\\company\\config.properties"); // load config.properties
            prop.load(input);
            String server = prop.getProperty("server");
            int port = Integer.parseInt(prop.getProperty("port"));
            s = new Socket(server,port);
            DataOutputStream dout = new DataOutputStream(s.getOutputStream());
            dout.writeUTF("Request Data");
            dout.flush();

        } catch (Exception e) {
            System.out.print(e);
        }
    }


    public static void NewFile(){
        try {
            DataInputStream dis=new DataInputStream(s.getInputStream());
            filetxt=(String)dis.readUTF();

            System.out.println(filetxt);
            Object obj= JSONValue.parse(filetxt);
            JSONObject jsonObject = (JSONObject) obj;
            JSONArray elm = (JSONArray) jsonObject.get("murid");
            FileWriter writer = new FileWriter("C:\\SFWBTPNS\\Bootcamp G2 Academy\\Belajar Java\\Har8\\Kedua\\src\\com\\company\\FileProses.txt");
            BufferedWriter buffer = new BufferedWriter(writer);
            for (int i = 0, size = elm.size(); i < size; i++)
            {
                JSONObject objectInArray = (JSONObject)elm.get(i);
                buffer.write("nama : "+objectInArray.get("nama")+"\nfisika : "+objectInArray.get("nilai fisika")+"\nkimia : "+objectInArray.get("nilai kimia")+"\nbiologi : "+objectInArray.get("nilai biologi")+"\n\n");
            }
            buffer.close();
            writer.close();
            System.out.println(jsonObject);
        }catch (Exception e){
            System.out.print(e);
        }
    }

    public static void MultiThreading(){
        PrintToScreen printData =new PrintToScreen (filetxt);
        FTPUpload uploadFTP = new FTPUpload();

        printData.start();
        uploadFTP.start();
    }

    // Method Download file dari FTP Server
    public static void Download(){
        try {
            // Config FTP
            String server = "ftp.myth.co.id";
            int port = 21;
            String user = "ftpuser@myth.co.id";
            String pass = "password";

            FTPClient ftpClient = new FTPClient();
            try {

                ftpClient.connect(server, port);
                ftpClient.login(user, pass);
                ftpClient.enterLocalPassiveMode();
                ftpClient.setFileType(FTP.BINARY_FILE_TYPE);

                // APPROACH #1: using retrieveFile(String, OutputStream)
                String remoteFile1 = "/download/average.txt";
                File downloadFile1 = new File("C:\\SFWBTPNS\\Bootcamp G2 Academy\\Belajar Java\\Tugas3\\average.txt");
                OutputStream out = new BufferedOutputStream(new FileOutputStream(downloadFile1));
                boolean success = ftpClient.retrieveFile(remoteFile1, out);
                out.close();

                if (success) {
                    System.out.println("File has been downloaded successfully.");
                }
            } catch (IOException ex) {
                System.out.println("Error: " + ex.getMessage());
                ex.printStackTrace();
            }
        }catch (Exception e){
            System.out.println(e);
        }
    }
    public static void ReleaseConn(){
        try {
            s.close();
            System.out.println("Success!!!");
        }catch (Exception e){
            System.out.println(e);
        }
    }
}
