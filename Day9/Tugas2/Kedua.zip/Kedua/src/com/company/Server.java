package com.company;

import java.util.*;
import java.net.*;
import java.io.*;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;


public class Server {
    public static boolean LoggedIn = false;
    public static Scanner keyboard = new Scanner(System.in);

    public static void main(String[] args) throws Exception{ 
        Properties prop = new Properties();
        InputStream input = null;
        try {
            input = new FileInputStream(args[0]);
            // load a properties file
            prop.load(input);
            mulai(prop.getProperty("port"),args[1]);
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            if (input != null) {
                try {
                    input.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static void mulai(String prop, String file){
        String textfile = "";
        try{
            ServerSocket ss=new ServerSocket(Integer.parseInt(prop));

                FileReader fr = new FileReader(file);
                BufferedReader br = new BufferedReader(fr);
                int i;
                while ((i = br.read()) != -1) {
                    textfile += (char) i;
                }
                fr.close();
                br.close();

                Socket s = ss.accept();

            String[] values = textfile.split("\\n");
            JSONArray arr = new JSONArray();
            JSONObject murid = new JSONObject();
            for (String string : values){
                String[] data = string.split(",");
                JSONObject obj1=new JSONObject();
                for (int j = 0; j<data.length; j++){
                    if (j==0){
                        obj1.put("nama",data[j]);
                    } else if (j==1){
                        obj1.put("nilai fisika",data[j]);
                    } else if (j==2){
                        obj1.put("nilai biologi",data[j]);
                    } else if (j==3){
                        obj1.put("nilai kimia",data[j]);
                    }
                }
                arr.add(obj1);

            }
            murid.put("murid",arr);
            String jsonText = JSONValue.toJSONString(murid);
            System.out.println(jsonText);
            DataOutputStream dout=new DataOutputStream(s.getOutputStream());
            DataInputStream dis=new DataInputStream(s.getInputStream());
            String str=(String)dis.readUTF();
            System.out.println(str);
            if(str.equals("Request Data")) {
                dout.writeUTF(jsonText);
                dout.flush();
                dout.close();
            }

        }catch(Exception e){
               System.out.println(e);
           }
    }
}