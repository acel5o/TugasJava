package com.company;

import java.io.*;
import java.net.*;
import java.util.Properties;
import java.io.DataOutputStream;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;


public class Client {
    //Instance Variable br -> scanner
    static InputStreamReader r=new InputStreamReader(System.in);
    static BufferedReader br=new BufferedReader(r);
    static Socket s; // Tampung socket
    static String data;// Variable untuk menampung string data file.txt dari server

    //Main Method
    public static void main(String[] args) {
        Menu();
    }

    public static void Menu(){
        try {
            int Menu = 0;
            while(Menu!=99){
                // Print Menu
                System.out.println("Menu");
                System.out.println("1. Connect Socket");
                System.out.println("2. Create FileProses.txt");
                System.out.println("3. Tampil Dilayar, Tulis Ke File, Kirim FTP (Multi Threading)");
                System.out.println("4. Download average.txt dari FTP Server");
                System.out.println("5. Close All Connection");
                System.out.println("99. Exit");
                System.out.println("");
                System.out.print("Input Menu : ");
                Menu = Integer.parseInt(br.readLine());
                switch (Menu){
                    case 1:
                        ConnSocket();
                        break;
                    case 2:
                        NewFile();
                        break;
                    case 3:
                        MultiThreading();
                        break;
                    case 4:
                        Download();
                        break;
                    case 5:
                        ReleaseConn();
                        break;
                    default:
                        break;
                }
            }
        }catch (Exception e){
            System.out.println(e);
        }
    }
    //Method koneksi ke Server
    public static void ConnSocket(){
        try {
            Properties prop = new Properties();
            InputStream input = null;
            input = new FileInputStream("C:\\SFWBTPNS\\Bootcamp G2 Academy\\Belajar Java\\Tugas3\\src\\com\\company\\config.properties"); // load config.properties
            prop.load(input);
            String ip = prop.getProperty("IP");
            int port = Integer.parseInt(prop.getProperty("PORT"));
            s = new Socket(ip,port);
            DataOutputStream dout = new DataOutputStream(s.getOutputStream());
            dout.writeUTF("Request Data");
            dout.flush();
            DataInputStream din = new DataInputStream(s.getInputStream());
            data = din.readUTF();
        } catch (Exception e) {
            System.out.print(e);
        }
    }


    public static void NewFile(){
        try {
            String filetxt = "";

            String[] split1 = data.split("\\n");
            for (String string : split1) {
                String[] datafinal = string.split(",");
                for (int i = 0; i < datafinal.length; i++) {
                    if(i==0){
                        filetxt += "Nama : " + datafinal[i] + "\n";
                    }else if (i==1) {
                        filetxt += "Fisika : " + datafinal[i] + "\n";
                    }else if (i==2) {
                        filetxt += "Biologi : " + datafinal[i] + "\n";
                    }else if (i==3) {
                        filetxt += "Kimia : " + datafinal[i] + "\n\n";
                    }
                }
            }
            FileWriter fr = new FileWriter("FileProses.txt");
            fr.write(filetxt);
            fr.close();
        }catch (Exception e){
            System.out.print(e);
        }
    }


    public static void MultiThreading(){
        try {
            String filetxt = "";
            String[] dataawal = data.split("\\n");

            for (String string : dataawal) {
                String[] datafinal = string.split(",");
                for (int i = 0; i < datafinal.length; i++) {
                    if(i==0){
                        filetxt += "Nama : " + datafinal[i] + "\n";
                    }else if (i==1) {
                        filetxt += "Fisika : " + datafinal[i] + "\n";
                    }else if (i==2) {
                        filetxt += "Biologi : " + datafinal[i] + "\n";
                    }else if (i==3) {
                        filetxt += "Kimia : " + datafinal[i] + "\n\n";
                    }
                }
            }
            PrintToScreen t1 = new PrintToScreen(filetxt);
            Average t2 = new Average(data);
            FTPUpload t3 = new FTPUpload();
            t1.start();
            t2.start();
            t3.start();
        }catch (Exception e){System.out.println(e);}
    }

    // Method Download file dari FTP Server
    public static void Download(){
        try {
            // Config FTP
            String server = "ftp.myth.co.id";
            int port = 21;
            String user = "ftpuser@myth.co.id";
            String pass = "password";

            FTPClient ftpClient = new FTPClient();
            try {

                ftpClient.connect(server, port);
                ftpClient.login(user, pass);
                ftpClient.enterLocalPassiveMode();
                ftpClient.setFileType(FTP.BINARY_FILE_TYPE);

                // APPROACH #1: using retrieveFile(String, OutputStream)
                String remoteFile1 = "/download/average.txt";
                File downloadFile1 = new File("C:\\SFWBTPNS\\Bootcamp G2 Academy\\Belajar Java\\Tugas3\\average.txt");
                OutputStream out = new BufferedOutputStream(new FileOutputStream(downloadFile1));
                boolean success = ftpClient.retrieveFile(remoteFile1, out);
                out.close();

                if (success) {
                    System.out.println("File has been downloaded successfully.");
                }
            } catch (IOException ex) {
                System.out.println("Error: " + ex.getMessage());
                ex.printStackTrace();
            }
        }catch (Exception e){
            System.out.println(e);
        }
    }
    public static void ReleaseConn(){
        try {
            s.close();
            System.out.println("Success!!!");
        }catch (Exception e){
            System.out.println(e);
        }
    }
}
